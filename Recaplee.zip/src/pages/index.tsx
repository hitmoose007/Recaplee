export default function Home() {
  return <div>This is the empty home page.</div>;
}
