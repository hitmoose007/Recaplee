
export enum PageView {
  DASHBOARD = 'dashboard',
  STEP1VIEW = 'step1',
  STEP2VIEW= 'step2',
  SUMMARYVIEW = 'summary',
    COMPETITORVIEW = 'competitor',
    SUBSCRIPTION = 'subscription',
}
